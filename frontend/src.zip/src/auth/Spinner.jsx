export default function Spinner() {
  return <span className="spinner" aria-hidden="true" />;
}
