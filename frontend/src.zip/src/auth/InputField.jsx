import { useState } from "react";
import { AiOutlineEye, AiOutlineEyeInvisible } from "react-icons/ai";

/**
 * InputField — supports:
 *   • icon        — React node rendered on the left (e.g. <MdEmail />)
 *   • floating label — label animates inside the input when empty/unfocused
 *   • show/hide toggle for password fields
 *   • error / hint display
 */
export default function InputField({
  label,
  name,
  type = "text",
  value,
  onChange,
  placeholder,
  autoComplete,
  error,
  onKeyDown,
  hint,
  icon,
}) {
  const [focused,   setFocused]   = useState(false);
  const [showPass,  setShowPass]  = useState(false);

  const isPassword  = type === "password";
  const inputType   = isPassword ? (showPass ? "text" : "password") : type;
  const hasValue    = value && value.length > 0;
  const labelFloat  = focused || hasValue;

  return (
    <div className={`field-group ${error ? "field-group--error" : ""}`}>
      <div className={`input-wrapper ${focused ? "input-wrapper--focused" : ""} ${error ? "input-wrapper--error" : ""}`}>
        {/* Left icon */}
        {icon && (
          <span className={`input-icon ${focused ? "input-icon--active" : ""}`} aria-hidden="true">
            {icon}
          </span>
        )}

        {/* Floating label */}
        {label && (
          <label
            htmlFor={name}
            className={`floating-label ${icon ? "floating-label--with-icon" : ""} ${labelFloat ? "floating-label--active" : ""}`}
          >
            {label}
          </label>
        )}

        {/* Input */}
        <input
          id={name}
          name={name}
          type={inputType}
          value={value}
          onChange={onChange}
          onKeyDown={onKeyDown}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          placeholder={focused ? placeholder : ""}
          autoComplete={autoComplete}
          className={`auth-input ${icon ? "auth-input--with-icon" : ""} ${isPassword ? "auth-input--with-toggle" : ""}`}
          aria-invalid={!!error}
          aria-describedby={error ? `${name}-error` : hint ? `${name}-hint` : undefined}
        />

        {/* Show / hide toggle for password — keyboard accessible */}
        {isPassword && (
          <button
            type="button"
            className="password-toggle"
            onClick={() => setShowPass((v) => !v)}
            aria-label={showPass ? "Hide password" : "Show password"}
            aria-pressed={showPass}
          >
            {showPass ? <AiOutlineEyeInvisible size={17} /> : <AiOutlineEye size={17} />}
          </button>
        )}
      </div>

      {hint && !error && (
        <div id={`${name}-hint`} className="field-hint">
          {hint}
        </div>
      )}
      {error && (
        <div id={`${name}-error`} className="field-error" role="alert">
          {error}
        </div>
      )}
    </div>
  );
}
